

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-md-offset-2">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <br>
                <div class="card">
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>"/>
                    <div class="card-header text-center" style="background-color: #e3f2fd;">
                        Vartotojas: <b> <?php echo e(Auth::user()->name); ?></b>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <table class="table table-striped text-center">
                                        <thead>

                                    <tr>
                                        <th>Paletes</th>
                                        <th>Eilutes</th>
                                        <th>Išsaugota</th>
                                    </tr>
                                        </thead>
                                        <tbody>
                                    <?php $__currentLoopData = $trackers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tracker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($tracker['eilutes']); ?></td>
                                            <td><?php echo e($tracker['pallet']); ?></td>
                                            <td><?php echo e($tracker['created_at']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                        </div>


                    </div>
                </div>

            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>