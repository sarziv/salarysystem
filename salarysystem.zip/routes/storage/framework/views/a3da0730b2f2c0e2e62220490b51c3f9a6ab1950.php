

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-md-offset-2">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <br>
                <div class="card">
                    <div class="card-header text-center" style="background-color: #e3f2fd;">
                        Skaičiuok kiek uždirbai!
                    </div>
                    <div class="card-body">


              <?php echo Form::open(array('route' => 'add.store','method'=>'POST')); ?>

                        <?php echo $__env->make('forms.createForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo Form::close(); ?>


                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>